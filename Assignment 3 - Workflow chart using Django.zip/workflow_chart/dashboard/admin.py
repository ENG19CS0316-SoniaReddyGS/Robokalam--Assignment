from django.contrib import admin
from . models import CountryData

# Register your models here.
admin.site.register(CountryData)
